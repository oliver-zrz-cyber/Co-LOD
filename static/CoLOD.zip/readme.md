# Using Co-LOD Executable

## Setting the Number of LOD Levels
We recommend setting the LOD levels based on the scanning precision of the input model. 
For datasets with relatively complete detail scans (our criterion is whether windows are fully scanned), such as the "Composite Scene" dataset, we recommend an LOD level of 3. 
For less detailed data, like the "Metropolis" dataset, we recommend an LOD level of 2.

**Note:** Ensure the scale of the architectural models matches the scale of the actual buildings.

**Note:** We have included two scene datasets used in our paper. For additional scene data, please refer to the public datasets mentioned in our paper.

**Note:** In PowerShell, use ./CoLOD.exe --h for more information.